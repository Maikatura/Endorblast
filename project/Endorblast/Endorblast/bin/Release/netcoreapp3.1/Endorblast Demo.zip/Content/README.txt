﻿BEFORE EDITING ANYTHING IN THE CONTENT FOLDER!!!!
Here is some infomation about what could happen!


#########################################
#                                       #
#               Sprites                 #
#                                       #
#########################################

If you edit stuff like map you will get banned from the server since if your movement
is in a position that is not valid on our server your account will be banned!
If you haven't edited a map and still got banned send us a email at {email here}


Also every sprite here is not allowed to be used in your game!
We have just provided every sprite in a png format to easily change
the look of our sprites! If you are planing to sell all assets found here
and we finds out about someone reselling our sprites we are sorry to say but
we will most likely not provide every sprite in .png format anymore and we will
have everything packed inside the game files.

If you make sprites share it in our Discord and we might even include it in the game (with credits)

(OBS!) 
If we include it in the game we on the game team need to rework it to fit with
all colors pallets we use. If you already have used the pallet included in the contnet
folder the you are good at reading because you have read this.

(OBS! OBS!)
If you read this the thing above is only when the game has been released.


NOTE our sprites is also copyrighted therefore you will get into legal problems from us if you do anything of the following:
- Resell.
- Reskin to sell.
- Distribute without permissions.
- Claim that you made it but you didn't.
- Upload to game assets sites as free and/or paid assets to download.


#########################################
#                                       #
#              Source Code              #
#                                       #
#########################################

Well you can decompile the code and remake it if you want.
But we will not give out our latest source of our game to the public. Go to: 
https://github.com/ZyroLUL/Endorblast

For the somewhat updated version of the source code! Any modification of the source to
work with our latest build will result in a permanent ban of your game account and block
from making new accounts.


#########################################
#                                       #
#				  Tools                 #
#                                       #
#########################################

We use: 
Tiled				- (Free) For all Worlds to play on.
Aseprite			- (Paid) For most of the art.
Pixel FX Designer	- (Paid) For particle animations.

