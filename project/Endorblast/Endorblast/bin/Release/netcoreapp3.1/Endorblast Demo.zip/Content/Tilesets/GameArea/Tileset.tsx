<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Tileset" tilewidth="32" tileheight="32" tilecount="104" columns="13">
 <image source="Tileset.png" width="432" height="272"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="13">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="14" probability="0.6"/>
 <tile id="15">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="17">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="26">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="27">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="28">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="39" probability="0.6"/>
 <tile id="40" probability="0.6"/>
 <tile id="91">
  <properties>
   <property name="nez:isSlope" type="bool" value="true"/>
   <property name="nez:slopeTopLeft" type="int" value="31"/>
   <property name="nez:slopeTopRight" type="int" value="22"/>
  </properties>
  <objectgroup draworder="index" id="5">
   <object id="5" x="0" y="32">
    <polygon points="0,0 31.9902,-9.98333 32,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="92">
  <properties>
   <property name="nez:isSlope" type="bool" value="true"/>
   <property name="nez:slopeTopLeft" type="int" value="22"/>
   <property name="nez:slopeTopRight" type="int" value="10"/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="nez:isSlope" type="bool" value="true"/>
   <property name="nez:slopeTopLeft" type="int" value="10"/>
   <property name="nez:slopeTopRight" type="int" value="0"/>
  </properties>
 </tile>
</tileset>
