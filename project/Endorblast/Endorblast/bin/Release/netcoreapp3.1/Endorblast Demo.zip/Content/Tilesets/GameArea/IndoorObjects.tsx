<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="IndoorObjects" tilewidth="32" tileheight="32" tilecount="34" columns="17">
 <image source="obj_indoors.png" width="544" height="64"/>
</tileset>
