<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Enviorment2" tilewidth="32" tileheight="32" tilecount="104" columns="13">
 <image source="Enviorment2.png" width="432" height="272"/>
</tileset>
