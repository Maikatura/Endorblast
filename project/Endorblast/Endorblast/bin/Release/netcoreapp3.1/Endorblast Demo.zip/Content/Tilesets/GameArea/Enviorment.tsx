<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Enviorment" tilewidth="506" tileheight="506" tilecount="3" columns="0" objectalignment="top">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="4">
  <image width="160" height="192" source="Tree1.png"/>
 </tile>
 <tile id="5">
  <image width="160" height="192" source="Tree2.png"/>
 </tile>
 <tile id="6">
  <image width="506" height="506" source="House1.png"/>
 </tile>
</tileset>
